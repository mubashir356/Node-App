// ============================================================================
// DYNAMIC DISCOUNT GENERATOR BACKEND
// Creates unique, one-time-use discount codes based on cart metafields
// ============================================================================

require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Shopify configuration
const SHOPIFY_STORE = process.env.SHOPIFY_STORE;
const SHOPIFY_ACCESS_TOKEN = process.env.SHOPIFY_ACCESS_TOKEN;
const SHOPIFY_API_VERSION = '2024-01';

// Helper function to make Shopify API calls
async function shopifyFetch(endpoint, method = 'GET', body = null) {
  const url = `https://${SHOPIFY_STORE}/admin/api/${SHOPIFY_API_VERSION}/${endpoint}`;
  
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'X-Shopify-Access-Token': SHOPIFY_ACCESS_TOKEN
    }
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Shopify API Error: ${response.status} - ${errorText}`);
  }

  return response.json();
}

// Generate unique discount code
function generateUniqueCode(customerId) {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `AUTO_${customerId}_${timestamp}_${random}`;
}

// Create price rule and discount code
async function createDiscountCode(discountAmount, customerId, customerEmail) {
  console.log(`Creating discount: $${(discountAmount / 100).toFixed(2)} for customer ${customerId}`);

  // Step 1: Create Price Rule
  const priceRuleBody = {
    price_rule: {
      title: `Auto Discount - ${customerEmail} - ${new Date().toISOString()}`,
      target_type: 'line_item',
      target_selection: 'all',
      allocation_method: 'across',
      value_type: 'fixed_amount',
      value: `-${(discountAmount / 100).toFixed(2)}`,
      customer_selection: 'prerequisite',
      prerequisite_customer_ids: [customerId],
      once_per_customer: true,
      usage_limit: 1,
      starts_at: new Date().toISOString(),
      ends_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // Expires in 24 hours
    }
  };

  const priceRuleResponse = await shopifyFetch('price_rules.json', 'POST', priceRuleBody);
  const priceRuleId = priceRuleResponse.price_rule.id;

  console.log(`Price rule created: ${priceRuleId}`);

  // Step 2: Create Discount Code
  const discountCode = generateUniqueCode(customerId);
  
  const discountCodeBody = {
    discount_code: {
      code: discountCode
    }
  };

  await shopifyFetch(`price_rules/${priceRuleId}/discount_codes.json`, 'POST', discountCodeBody);

  console.log(`Discount code created: ${discountCode}`);

  return {
    code: discountCode,
    priceRuleId: priceRuleId,
    amount: discountAmount
  };
}

// Delete old discount codes
async function deleteDiscountCode(priceRuleId) {
  try {
    console.log(`Deleting price rule: ${priceRuleId}`);
    await shopifyFetch(`price_rules/${priceRuleId}.json`, 'DELETE');
    console.log(`Price rule deleted: ${priceRuleId}`);
    return true;
  } catch (error) {
    console.error(`Error deleting price rule ${priceRuleId}:`, error.message);
    return false;
  }
}

// ============================================================================
// API ENDPOINTS
// ============================================================================

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'Dynamic Discount Generator is running' });
});

// Generate discount code
app.post('/api/generate-discount', async (req, res) => {
  try {
    const { cartItems, customerTag, customerId, customerEmail } = req.body;

    console.log('\n=== New Discount Request ===');
    console.log('Customer:', customerId, customerEmail);
    console.log('Tag:', customerTag);
    console.log('Cart items:', cartItems.length);

    // Validate input
    if (!cartItems || !customerTag || !customerId) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing required fields' 
      });
    }

    // Calculate total discount
    let totalDiscount = 0;
    const breakdown = [];

    for (const item of cartItems) {
      const discount = calculateItemDiscount(item, customerTag);
      
      if (discount > 0) {
        totalDiscount += discount;
        breakdown.push({
          title: item.title,
          quantity: item.quantity,
          discount: discount
        });
      }
    }

    console.log(`Total discount calculated: $${(totalDiscount / 100).toFixed(2)}`);

    if (totalDiscount === 0) {
      return res.json({
        success: false,
        message: 'No discount applicable'
      });
    }

    // Create discount code
    const discountData = await createDiscountCode(totalDiscount, customerId, customerEmail);

    res.json({
      success: true,
      discountCode: discountData.code,
      priceRuleId: discountData.priceRuleId,
      discountAmount: totalDiscount,
      breakdown: breakdown
    });

  } catch (error) {
    console.error('Error generating discount:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Delete old discount code
app.post('/api/delete-discount', async (req, res) => {
  try {
    const { priceRuleId } = req.body;

    if (!priceRuleId) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing priceRuleId' 
      });
    }

    const deleted = await deleteDiscountCode(priceRuleId);

    res.json({
      success: deleted,
      message: deleted ? 'Discount deleted' : 'Failed to delete discount'
    });

  } catch (error) {
    console.error('Error deleting discount:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// ============================================================================
// DISCOUNT CALCULATION LOGIC
// ============================================================================

function calculateItemDiscount(item, customerTag) {
  const quantity = item.quantity;
  const regularPrice = item.price; // in cents
  
  // Get metafield values (in dollars, need to convert to cents)
  const wholesalePrice = item.variant?.metafields?.custom?.wholesale_price;
  const wholesale10Plus = item.variant?.metafields?.custom?.wholesale_10plus;
  const distributor20Price = item.variant?.metafields?.custom?.distributor_20;

  let discountPrice = null;

  // Determine which price to use
  if (customerTag === 'wholesale') {
    if (quantity >= 11 && wholesale10Plus) {
      discountPrice = wholesale10Plus * 100;
    } else if (quantity < 11 && wholesalePrice) {
      discountPrice = wholesalePrice * 100;
    }
  } else if (customerTag === 'distributor20') {
    if (quantity >= 11 && distributor20Price) {
      discountPrice = distributor20Price * 100;
    } else if (quantity < 11 && wholesale10Plus) {
      discountPrice = wholesale10Plus * 100;
    }
  }

  // Calculate discount
  if (discountPrice !== null && discountPrice < regularPrice) {
    const difference = regularPrice - discountPrice;
    return difference * quantity;
  }

  return 0;
}

// ============================================================================
// START SERVER
// ============================================================================

app.listen(PORT, () => {
  console.log(`\n✅ Dynamic Discount Generator Backend`);
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🏪 Shopify Store: ${SHOPIFY_STORE}`);
  console.log(`📍 Health check: http://localhost:${PORT}/health\n`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  process.exit(0);
});

module.exports = app;